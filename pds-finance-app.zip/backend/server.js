import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import authRoutes from './src/routes/auth.js';
import walletRoutes from './src/routes/wallets.js';
import categoryRoutes from './src/routes/categories.js';
import transactionRoutes from './src/routes/transactions.js';
import reportRoutes from './src/routes/reports.js';

dotenv.config();
const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || '*', credentials: true }));
app.use(express.json());
app.use(morgan('dev'));

app.get('/', (req, res) => res.json({ ok: true, service: 'PDS Finance API' }));

app.use('/api/auth', authRoutes);
app.use('/api/wallets', walletRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/reports', reportRoutes);

const PORT = process.env.PORT || 4000;
const MONGO_URI = process.env.MONGO_URI;

mongoose.connect(MONGO_URI).then(() => {
  console.log('Mongo connected');
  app.listen(PORT, () => console.log('Server running on ' + PORT));
}).catch(err => {
  console.error('Mongo connection error', err.message);
  process.exit(1);
});
