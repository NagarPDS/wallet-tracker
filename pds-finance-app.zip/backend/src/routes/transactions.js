import express from 'express';
import { authRequired } from '../middleware/auth.js';
import Transaction from '../models/Transaction.js';
import Wallet from '../models/Wallet.js';
import { recalcWalletBalance } from '../utils/balances.js';

const router = express.Router();
router.use(authRequired);

router.get('/', async (req, res) => {
  const { start, end, category, wallet, tax, type } = req.query;
  const q = { user: req.userId };
  if (start || end) {
    q.date = {};
    if (start) q.date.$gte = new Date(start);
    if (end) q.date.$lte = new Date(end);
  }
  if (category) q.category = category;
  if (wallet) q.$or = [{ wallet }, { walletTo: wallet }];
  if (tax === 'yes') q.taxDeductible = true;
  if (tax === 'no') q.taxDeductible = false;
  if (type) q.type = type;
  const items = await Transaction.find(q).populate('category').populate('wallet').populate('walletTo').sort({ date: -1, createdAt: -1 });
  res.json(items);
});

router.post('/', async (req, res) => {
  const { date, amount, type, category, wallet, walletTo, taxDeductible, taxRate, description } = req.body;
  if (!date || !amount || !type) return res.status(400).json({ error: 'date, amount, type are required' });

  // Basic validation for transfers
  if (type === 'Transfer') {
    if (!wallet || !walletTo) return res.status(400).json({ error: 'Transfer requires wallet and walletTo' });
    if (wallet === walletTo) return res.status(400).json({ error: 'wallet and walletTo must differ for transfers' });
  }

  const tx = await Transaction.create({
    user: req.userId, date, amount, type, category: category || null,
    wallet: wallet || null, walletTo: walletTo || null,
    taxDeductible: !!taxDeductible, taxRate: taxRate || 0, description: description || ''
  });

  // Recalculate affected wallets
  if (wallet) await recalcWalletBalance(wallet, req.userId);
  if (walletTo) await recalcWalletBalance(walletTo, req.userId);

  res.json(tx);
});

router.put('/:id', async (req, res) => {
  const existing = await Transaction.findOne({ _id: req.params.id, user: req.userId });
  if (!existing) return res.status(404).json({ error: 'Not found' });

  const { date, amount, type, category, wallet, walletTo, taxDeductible, taxRate, description } = req.body;

  const oldWallets = { wallet: existing.wallet?.toString(), walletTo: existing.walletTo?.toString() };

  existing.date = date ?? existing.date;
  existing.amount = amount ?? existing.amount;
  existing.type = type ?? existing.type;
  existing.category = category ?? existing.category;
  existing.wallet = wallet ?? existing.wallet;
  existing.walletTo = walletTo ?? existing.walletTo;
  existing.taxDeductible = taxDeductible ?? existing.taxDeductible;
  existing.taxRate = taxRate ?? existing.taxRate;
  existing.description = description ?? existing.description;
  await existing.save();

  const affected = set()
  const affected = new Set();
  if (oldWallets.wallet) affected.add(oldWallets.wallet);
  if (oldWallets.walletTo) affected.add(oldWallets.walletTo);
  if (existing.wallet) affected.add(existing.wallet.toString());
  if (existing.walletTo) affected.add(existing.walletTo.toString());

  for (const w of affected) await recalcWalletBalance(w, req.userId);

  res.json(existing);
});

router.delete('/:id', async (req, res) => {
  const existing = await Transaction.findOne({ _id: req.params.id, user: req.userId });
  if (!existing) return res.status(404).json({ error: 'Not found' });
  const affected = new Set();
  if (existing.wallet) affected.add(existing.wallet.toString());
  if (existing.walletTo) affected.add(existing.walletTo.toString());
  await existing.deleteOne();
  for (const w of affected) await recalcWalletBalance(w, req.userId);
  res.json({ ok: true });
});

export default router;
