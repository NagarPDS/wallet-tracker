import express from 'express';
import { authRequired } from '../middleware/auth.js';
import Category from '../models/Category.js';

const router = express.Router();
router.use(authRequired);

router.get('/', async (req, res) => {
  const items = await Category.find({ user: req.userId }).sort({ name: 1 });
  res.json(items);
});

router.post('/', async (req, res) => {
  const { name, kind } = req.body;
  const item = await Category.create({ user: req.userId, name, kind });
  res.json(item);
});

router.put('/:id', async (req, res) => {
  const { name, kind } = req.body;
  const item = await Category.findOneAndUpdate({ _id: req.params.id, user: req.userId }, { name, kind }, { new: true });
  res.json(item);
});

router.delete('/:id', async (req, res) => {
  await Category.deleteOne({ _id: req.params.id, user: req.userId });
  res.json({ ok: true });
});

export default router;
