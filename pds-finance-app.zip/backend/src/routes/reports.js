import express from 'express';
import { authRequired } from '../middleware/auth.js';
import Transaction from '../models/Transaction.js';

const router = express.Router();
router.use(authRequired);

router.get('/dashboard', async (req, res) => {
  const { start, end } = req.query;
  const q = { user: req.userId };
  if (start || end) {
    q.date = {};
    if (start) q.date.$gte = new Date(start);
    if (end) q.date.$lte = new Date(end);
  }
  const [incomeAgg] = await Transaction.aggregate([
    { $match: { ...q, type: 'Income' } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]);
  const [expenseAgg] = await Transaction.aggregate([
    { $match: { ...q, type: 'Expense' } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]);
  res.json({
    totalIncome: incomeAgg?.total || 0,
    totalExpense: expenseAgg?.total || 0,
    net: (incomeAgg?.total || 0) - (expenseAgg?.total || 0)
  });
});

router.get('/tax', async (req, res) => {
  const { year, month, rate } = req.query;
  const q = { user: req.userId, type: 'Expense', taxDeductible: true };
  if (rate) q.taxRate = Number(rate);
  if (year || month) {
    const start = new Date(Number(year || new Date().getFullYear()), Number(month || 0), 1);
    const end = new Date(start);
    if (month !== undefined) {
      end.setMonth(end.getMonth() + 1);
    } else {
      end.setFullYear(end.getFullYear() + 1);
    }
    q.date = { $gte: start, $lt: end };
  }
  const items = await Transaction.find(q).sort({ date: -1 });
  const total = items.reduce((s, t) => s + t.amount, 0);
  const gst = items.reduce((s, t) => s + (t.amount * (t.taxRate || 0) / 100), 0);
  res.json({ items, total, gst });
});

router.get('/category-summary', async (req, res) => {
  const { start, end } = req.query;
  const match = { user: req.userId, type: 'Expense' };
  if (start || end) {
    match.date = {};
    if (start) match.date.$gte = new Date(start);
    if (end) match.date.$lte = new Date(end);
  }
  const agg = await Transaction.aggregate([
    { $match: match },
    { $group: { _id: '$category', total: { $sum: '$amount' } } },
    { $sort: { total: -1 } }
  ]);
  res.json(agg);
});

router.get('/wallet-summary', async (req, res) => {
  const { start, end } = req.query;
  const match = { user: req.userId, type: 'Expense' };
  if (start || end) {
    match.date = {};
    if (start) match.date.$gte = new Date(start);
    if (end) match.date.$lte = new Date(end);
  }
  const agg = await Transaction.aggregate([
    { $match: match },
    { $group: { _id: '$wallet', total: { $sum: '$amount' } } },
    { $sort: { total: -1 } }
  ]);
  res.json(agg);
});

export default router;
