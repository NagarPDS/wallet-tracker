import express from 'express';
import { authRequired } from '../middleware/auth.js';
import Wallet from '../models/Wallet.js';
import { recalcWalletBalance } from '../utils/balances.js';

const router = express.Router();
router.use(authRequired);

router.get('/', async (req, res) => {
  const items = await Wallet.find({ user: req.userId }).sort({ createdAt: 1 });
  res.json(items);
});

router.post('/', async (req, res) => {
  const { name, type } = req.body;
  const item = await Wallet.create({ user: req.userId, name, type });
  res.json(item);
});

router.put('/:id', async (req, res) => {
  const { name, type } = req.body;
  const item = await Wallet.findOneAndUpdate({ _id: req.params.id, user: req.userId }, { name, type }, { new: true });
  res.json(item);
});

router.delete('/:id', async (req, res) => {
  await Wallet.deleteOne({ _id: req.params.id, user: req.userId });
  res.json({ ok: true });
});

router.post('/:id/recalc', async (req, res) => {
  const balance = await recalcWalletBalance(req.params.id, req.userId);
  res.json({ balance });
});

export default router;
