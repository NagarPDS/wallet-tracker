import mongoose from 'mongoose';

const CategorySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  kind: { type: String, enum: ['Income','Expense','Transfer','Any'], default: 'Any' }
}, { timestamps: true });

export default mongoose.model('Category', CategorySchema);
