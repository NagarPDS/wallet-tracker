import mongoose from 'mongoose';

const TransactionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  date: { type: Date, required: true },
  amount: { type: Number, required: true },
  type: { type: String, enum: ['Income','Expense','Transfer'], required: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: false },
  wallet: { type: mongoose.Schema.Types.ObjectId, ref: 'Wallet', required: false },
  walletTo: { type: mongoose.Schema.Types.ObjectId, ref: 'Wallet', required: false }, // for transfer
  taxDeductible: { type: Boolean, default: false },
  taxRate: { type: Number, default: 0 },
  description: { type: String, default: '' }
}, { timestamps: true });

export default mongoose.model('Transaction', TransactionSchema);
