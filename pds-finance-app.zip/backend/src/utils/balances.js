import Wallet from '../models/Wallet.js';
import Transaction from '../models/Transaction.js';

export async function recalcWalletBalance(walletId, userId) {
  const income = await Transaction.aggregate([
    { $match: { user: userId, wallet: walletId, type: 'Income' } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]);
  const expense = await Transaction.aggregate([
    { $match: { user: userId, wallet: walletId, type: 'Expense' } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]);
  const transfersOut = await Transaction.aggregate([
    { $match: { user: userId, type: 'Transfer', wallet: walletId } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]);
  const transfersIn = await Transaction.aggregate([
    { $match: { user: userId, type: 'Transfer', walletTo: walletId } },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]);

  const totalIncome = income[0]?.total || 0;
  const totalExpense = expense[0]?.total || 0;
  const totalOut = transfersOut[0]?.total || 0;
  const totalIn = transfersIn[0]?.total || 0;

  const balance = totalIncome - totalExpense - totalOut + totalIn;
  await Wallet.findOneAndUpdate({ _id: walletId, user: userId }, { balance });
  return balance;
}
