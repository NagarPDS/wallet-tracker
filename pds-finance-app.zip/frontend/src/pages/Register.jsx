import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api from '../api'

export default function Register(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')
  const [error, setError] = useState('')
  const nav = useNavigate()

  const submit = async e => {
    e.preventDefault()
    setError(''); setMsg('')
    try{
      await api.post('/api/auth/register', { email, password })
      setMsg('Account created. Please login.')
      setTimeout(()=>nav('/login'), 800)
    }catch(err){
      setError(err.response?.data?.error || 'Registration failed')
    }
  }

  return (
    <div className="container max-w-md">
      <h1 className="text-2xl font-semibold my-6 text-primary-800">Create account</h1>
      <form onSubmit={submit} className="card p-6 space-y-3">
        {msg && <div className="text-green-700 text-sm">{msg}</div>}
        {error && <div className="text-red-600 text-sm">{error}</div>}
        <div>
          <div className="label">Email</div>
          <input className="input" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/>
        </div>
        <div>
          <div className="label">Password</div>
          <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Choose a strong password"/>
        </div>
        <button className="btn w-full">Register</button>
        <div className="text-sm">
          Have an account? <Link to="/login" className="text-primary-700">Login</Link>
        </div>
      </form>
    </div>
  )
}
