import { useEffect, useState } from 'react'
import api from '../api'

export default function Wallets(){
  const [items, setItems] = useState([])
  const [name, setName] = useState('')
  const [type, setType] = useState('Cash')

  const load = async ()=>{
    const { data } = await api.get('/api/wallets')
    setItems(data)
  }
  useEffect(()=>{ load() }, [])

  const add = async ()=>{
    const { data } = await api.post('/api/wallets', { name, type })
    setName(''); setType('Cash'); setItems([...items, data])
  }
  const del = async id => {
    await api.delete('/api/wallets/' + id)
    setItems(items.filter(x=>x._id!==id))
  }

  return (
    <div className="container">
      <h1 className="text-2xl font-semibold my-6">Wallets</h1>
      <div className="grid md:grid-cols-3 gap-4">
        <div className="card p-4 md:col-span-2">
          <div className="grid md:grid-cols-3 gap-3">
            {items.map(w=>(
              <div key={w._id} className="border rounded-lg p-4">
                <div className="text-sm text-gray-500">{w.type}</div>
                <div className="font-semibold">{w.name}</div>
                <div className="text-lg mt-2">₹{Number(w.balance||0).toFixed(2)}</div>
                <button className="text-red-600 text-sm mt-2" onClick={()=>del(w._id)}>Delete</button>
              </div>
            ))}
          </div>
        </div>
        <div className="card p-4">
          <div className="font-semibold mb-2">Add wallet</div>
          <div className="label">Name</div>
          <input className="input" value={name} onChange={e=>setName(e.target.value)} />
          <div className="label mt-2">Type</div>
          <select className="input" value={type} onChange={e=>setType(e.target.value)}>
            {['Cash','Bank','UPI','Credit Card','Other'].map(t=> <option key={t}>{t}</option>)}
          </select>
          <button className="btn w-full mt-3" onClick={add}>Add</button>
        </div>
      </div>
    </div>
  )
}
