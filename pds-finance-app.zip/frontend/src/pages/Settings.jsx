import { useEffect, useState } from 'react'
import api from '../api'

export default function Settings(){
  const [categories, setCategories] = useState([])
  const [name, setName] = useState('')
  const [kind, setKind] = useState('Any')

  const load = async ()=>{
    const { data } = await api.get('/api/categories')
    setCategories(data)
  }
  useEffect(()=>{ load() }, [])

  const add = async ()=>{
    const { data } = await api.post('/api/categories', { name, kind })
    setName(''); setKind('Any'); setCategories([...categories, data])
  }
  const del = async id => {
    await api.delete('/api/categories/'+id)
    setCategories(categories.filter(x=>x._id!==id))
  }

  return (
    <div className="container">
      <h1 className="text-2xl font-semibold my-6">Settings</h1>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="card p-4">
          <div className="font-semibold mb-2">Categories</div>
          <div className="grid grid-cols-2 gap-2">
            {categories.map(c=>(
              <div key={c._id} className="border rounded p-2 flex items-center justify-between">
                <div>{c.name} <span className="text-xs text-gray-500">({c.kind})</span></div>
                <button onClick={()=>del(c._id)} className="text-red-600 text-sm">Delete</button>
              </div>
            ))}
          </div>
        </div>
        <div className="card p-4">
          <div className="font-semibold mb-2">Add category</div>
          <div className="label">Name</div>
          <input className="input" value={name} onChange={e=>setName(e.target.value)} />
          <div className="label mt-2">Kind</div>
          <select className="input" value={kind} onChange={e=>setKind(e.target.value)}>
            {['Any','Income','Expense','Transfer'].map(k=><option key={k}>{k}</option>)}
          </select>
          <button className="btn w-full mt-3" onClick={add}>Add</button>
        </div>
      </div>
    </div>
  )
}
