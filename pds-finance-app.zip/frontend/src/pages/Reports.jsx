import { useEffect, useState } from 'react'
import api from '../api'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

export default function Reports(){
  const [cat, setCat] = useState([])
  const [wallet, setWallet] = useState([])
  const [tax, setTax] = useState({ items:[], total:0, gst:0 })
  const [year, setYear] = useState(new Date().getFullYear().toString())
  const [month, setMonth] = useState('')

  const load = async ()=>{
    const c = await api.get('/api/reports/category-summary')
    setCat(c.data.map(x=>({ name: x._id || 'Uncategorized', value: x.total })))
    const w = await api.get('/api/reports/wallet-summary')
    setWallet(w.data.map(x=>({ name: x._id || 'Unknown', value: x.total })))
    const t = await api.get('/api/reports/tax', { params: { year } })
    setTax(t.data)
  }
  useEffect(()=>{ load() }, [year, month])

  const fetchTax = async ()=>{
    const params = {}
    if (year) params.year = year
    if (month) params.month = month
    const t = await api.get('/api/reports/tax', { params })
    setTax(t.data)
  }

  return (
    <div className="container">
      <h1 className="text-2xl font-semibold my-6">Reports</h1>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="card p-4">
          <div className="font-semibold mb-2">Category wise expense</div>
          <div className="h-72">
            <ResponsiveContainer>
              <BarChart data={cat}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-4">
          <div className="font-semibold mb-2">Wallet wise expense</div>
          <div className="h-72">
            <ResponsiveContainer>
              <BarChart data={wallet}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="card p-4 mt-4">
        <div className="font-semibold mb-2">Tax report</div>
        <div className="flex gap-2 mb-3">
          <input className="input" placeholder="Year YYYY" value={year} onChange={e=>setYear(e.target.value)} />
          <input className="input" placeholder="Month 0-11, optional" value={month} onChange={e=>setMonth(e.target.value)} />
          <button className="btn" onClick={fetchTax}>Refresh</button>
        </div>
        <div className="text-sm">Deductible total: ₹{tax.total.toFixed(2)} | GST estimate: ₹{tax.gst.toFixed(2)}</div>
        <div className="overflow-auto mt-3">
          <table className="w-full text-sm">
            <thead><tr>
              <th className="p-2">Date</th><th className="p-2">Amount</th><th className="p-2">Rate</th><th className="p-2">Desc</th>
            </tr></thead>
            <tbody>
              {tax.items.map((t,i)=>(
                <tr key={i} className="border-b">
                  <td className="p-2">{new Date(t.date).toISOString().slice(0,10)}</td>
                  <td className="p-2">{t.amount}</td>
                  <td className="p-2">{t.taxRate}</td>
                  <td className="p-2">{t.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
