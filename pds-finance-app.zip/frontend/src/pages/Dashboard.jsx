import { useEffect, useState } from 'react'
import api from '../api'
import { Link } from 'react-router-dom'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'

export default function Dashboard(){
  const [summary, setSummary] = useState({ totalIncome:0,totalExpense:0,net:0 })
  const [catData, setCatData] = useState([])

  useEffect(()=>{
    (async ()=>{
      const { data } = await api.get('/api/reports/dashboard')
      setSummary(data)
      const cats = await api.get('/api/reports/category-summary')
      setCatData(cats.data.map(x=>({ name: x._id || 'Uncategorized', value: x.total })))
    })()
  }, [])

  const COLORS = ['#8b5cf6','#a78bfa','#c4b5fd','#ddd6fe','#4c1d95']

  return (
    <div className="container">
      <h1 className="text-2xl font-semibold my-6">Dashboard</h1>
      <div className="grid md:grid-cols-3 gap-4">
        <div className="card p-4">
          <div className="text-sm text-gray-500">Total Income</div>
          <div className="text-3xl font-semibold text-green-700">₹{summary.totalIncome.toFixed(2)}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-gray-500">Total Expense</div>
          <div className="text-3xl font-semibold text-red-700">₹{summary.totalExpense.toFixed(2)}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-gray-500">Net</div>
          <div className="text-3xl font-semibold">{summary.net >= 0 ? '₹'+summary.net.toFixed(2) : '-₹'+Math.abs(summary.net).toFixed(2)}</div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4 mt-6">
        <div className="card p-4">
          <div className="flex items-center justify-between">
            <div className="font-semibold">Category wise expenses</div>
            <Link to="/reports" className="text-primary-700 text-sm">View reports</Link>
          </div>
          <div className="h-72">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={catData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
                  {catData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card p-4">
          <div className="font-semibold mb-2">Quick actions</div>
          <div className="flex gap-3">
            <Link to="/transactions" className="btn">Add transaction</Link>
            <Link to="/wallets" className="btn">Manage wallets</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
