import { useEffect, useMemo, useState } from 'react'
import api from '../api'

export default function Transactions(){
  const [txs, setTxs] = useState([])
  const [wallets, setWallets] = useState([])
  const [categories, setCategories] = useState([])

  const [form, setForm] = useState({ date: new Date().toISOString().slice(0,10), amount: '', type: 'Expense', category: '', wallet: '', walletTo: '', taxDeductible: false, taxRate: 0, description: '' })
  const [filters, setFilters] = useState({ type:'', wallet:'', tax:'', start:'', end:'' })

  const load = async ()=>{
    const [w, c, t] = await Promise.all([
      api.get('/api/wallets'),
      api.get('/api/categories'),
      api.get('/api/transactions')
    ])
    setWallets(w.data); setCategories(c.data); setTxs(t.data)
  }
  useEffect(()=>{ load() }, [])

  const refreshTxs = async ()=>{
    const params = {}
    for (const k in filters) if (filters[k]) params[k] = filters[k]
    const { data } = await api.get('/api/transactions', { params })
    setTxs(data)
  }

  const submit = async e => {
    e.preventDefault()
    const payload = { ...form, amount: Number(form.amount) }
    const { data } = await api.post('/api/transactions', payload)
    setForm({ date: new Date().toISOString().slice(0,10), amount: '', type: 'Expense', category: '', wallet: '', walletTo: '', taxDeductible: false, taxRate: 0, description: '' })
    setTxs([data, ...txs])
  }

  const del = async id => {
    await api.delete('/api/transactions/'+id)
    setTxs(txs.filter(x=>x._id!==id))
  }

  const exportCSV = ()=>{
    const header = ['Date','Amount','Type','Category','Wallet','WalletTo','TaxDeductible','TaxRate','Description']
    const rows = txs.map(t=>[
      new Date(t.date).toISOString().slice(0,10),
      t.amount, t.type,
      t.category?.name || '',
      t.wallet?.name || '',
      t.walletTo?.name || '',
      t.taxDeductible ? 'Yes' : 'No',
      t.taxRate || 0,
      '"' + (t.description||'').replaceAll('"','""') + '"'
    ])
    const csv = [header.join(','), ...rows.map(r=>r.join(','))].join('\n')
    const blob = new Blob([csv], { type:'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'transactions.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  const showWalletTo = form.type === 'Transfer'

  return (
    <div className="container">
      <h1 className="text-2xl font-semibold my-6">Transactions</h1>
      <div className="grid md:grid-cols-3 gap-4">
        <div className="card p-4 md:col-span-2">
          <div className="flex gap-2 mb-3">
            <input className="input" type="date" value={filters.start} onChange={e=>setFilters({...filters,start:e.target.value})} />
            <input className="input" type="date" value={filters.end} onChange={e=>setFilters({...filters,end:e.target.value})} />
            <select className="input" value={filters.type} onChange={e=>setFilters({...filters,type:e.target.value})}>
              <option value="">All types</option>
              {['Income','Expense','Transfer'].map(t=><option key={t}>{t}</option>)}
            </select>
            <select className="input" value={filters.tax} onChange={e=>setFilters({...filters,tax:e.target.value})}>
              <option value="">Tax filter</option>
              <option value="yes">Tax deductible</option>
              <option value="no">Non deductible</option>
            </select>
            <button className="btn" onClick={refreshTxs}>Filter</button>
            <button className="btn" onClick={exportCSV}>Export CSV</button>
          </div>
          <div className="overflow-auto">
            <table className="w-full text-sm">
              <thead className="text-left bg-gray-50">
                <tr>
                  <th className="p-2">Date</th>
                  <th className="p-2">Amount</th>
                  <th className="p-2">Type</th>
                  <th className="p-2">Category</th>
                  <th className="p-2">Wallet</th>
                  <th className="p-2">Wallet To</th>
                  <th className="p-2">Tax</th>
                  <th className="p-2">Rate</th>
                  <th className="p-2">Description</th>
                  <th className="p-2"></th>
                </tr>
              </thead>
              <tbody>
                {txs.map(t=>(
                  <tr key={t._id} className="border-b">
                    <td className="p-2">{new Date(t.date).toISOString().slice(0,10)}</td>
                    <td className="p-2">{t.amount}</td>
                    <td className="p-2">{t.type}</td>
                    <td className="p-2">{t.category?.name || ''}</td>
                    <td className="p-2">{t.wallet?.name || ''}</td>
                    <td className="p-2">{t.walletTo?.name || ''}</td>
                    <td className="p-2">{t.taxDeductible ? 'Yes' : 'No'}</td>
                    <td className="p-2">{t.taxRate || 0}</td>
                    <td className="p-2">{t.description}</td>
                    <td className="p-2">
                      <button onClick={()=>del(t._id)} className="text-red-600">Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="card p-4">
          <div className="font-semibold mb-2">Add transaction</div>
          <div className="label">Date</div>
          <input className="input" type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} />
          <div className="label mt-2">Amount</div>
          <input className="input" type="number" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})} />
          <div className="label mt-2">Type</div>
          <select className="input" value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>
            {['Income','Expense','Transfer'].map(t=><option key={t}>{t}</option>)}
          </select>
          <div className="label mt-2">Category</div>
          <select className="input" value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>
            <option value="">None</option>
            {categories.map(c=><option key={c._id} value={c._id}>{c.name}</option>)}
          </select>
          <div className="label mt-2">Wallet</div>
          <select className="input" value={form.wallet} onChange={e=>setForm({...form,wallet:e.target.value})}>
            <option value="">None</option>
            {wallets.map(w=><option key={w._id} value={w._id}>{w.name}</option>)}
          </select>
          {showWalletTo && <>
            <div className="label mt-2">Wallet To</div>
            <select className="input" value={form.walletTo} onChange={e=>setForm({...form,walletTo:e.target.value})}>
              <option value="">None</option>
              {wallets.map(w=><option key={w._id} value={w._id}>{w.name}</option>)}
            </select>
          </>}
          <div className="label mt-2">Tax deductible</div>
          <input type="checkbox" checked={form.taxDeductible} onChange={e=>setForm({...form,taxDeductible:e.target.checked})} />
          <div className="label mt-2">GST or Tax rate</div>
          <input className="input" type="number" value={form.taxRate} onChange={e=>setForm({...form,taxRate:e.target.value})} />
          <div className="label mt-2">Description</div>
          <input className="input" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} />
          <button className="btn w-full mt-3" onClick={submit}>Save</button>
        </div>
      </div>
    </div>
  )
}
