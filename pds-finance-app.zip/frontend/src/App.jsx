import { Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Transactions from './pages/Transactions'
import Wallets from './pages/Wallets'
import Reports from './pages/Reports'
import Settings from './pages/Settings'
import { isAuthed } from './auth'

function PrivateRoute({ children }){
  return isAuthed() ? children : <Navigate to="/login" />
}

export default function App(){
  return (
    <div className="min-h-screen">
      <Navbar />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/" element={<PrivateRoute><Dashboard/></PrivateRoute>} />
        <Route path="/transactions" element={<PrivateRoute><Transactions/></PrivateRoute>} />
        <Route path="/wallets" element={<PrivateRoute><Wallets/></PrivateRoute>} />
        <Route path="/reports" element={<PrivateRoute><Reports/></PrivateRoute>} />
        <Route path="/settings" element={<PrivateRoute><Settings/></PrivateRoute>} />
      </Routes>
    </div>
  )
}
