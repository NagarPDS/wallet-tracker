import { Link, useNavigate } from 'react-router-dom';
import { clearToken, isAuthed } from '../auth';

export default function Navbar(){
  const nav = useNavigate();
  const logout = () => { clearToken(); nav('/login'); };
  return (
    <div className="bg-white border-b shadow-sm">
      <div className="container flex items-center justify-between py-3">
        <Link to="/" className="font-semibold text-primary-700">PDS Finance</Link>
        <div className="flex gap-4 text-sm">
          {isAuthed() && <>
            <Link to="/">Dashboard</Link>
            <Link to="/transactions">Transactions</Link>
            <Link to="/wallets">Wallets</Link>
            <Link to="/reports">Reports</Link>
            <Link to="/settings">Settings</Link>
            <button onClick={logout} className="text-red-600">Logout</button>
          </>}
        </div>
      </div>
    </div>
  )
}
