import jwt_decode from 'jwt-decode';

export function setToken(token) {
  localStorage.setItem('token', token);
}
export function getToken() {
  return localStorage.getItem('token');
}
export function clearToken() {
  localStorage.removeItem('token');
}
export function isAuthed() {
  const t = getToken();
  if (!t) return false;
  try {
    const { exp } = jwt_decode(t);
    return exp * 1000 > Date.now();
  } catch { return false; }
}
