# PDS Finance App

Full-stack expense and income tracker with wallets, tax reporting, and CSV export.

## Tech Stack
- Frontend: React + Vite + Tailwind
- Backend: Node.js + Express + Mongoose
- Database: MongoDB Atlas
- Auth: JWT

## Features
- Email registration and login
- Dashboard with totals and category charts
- Transactions CRUD with income, expense, transfer
- Wallet balances auto recalculated
- Tax module with monthly or yearly deductible totals and GST estimate
- Filters and CSV export
- Manage categories and wallets

## Quick Start

### 1. Backend
```bash
cd backend
cp .env.example .env
# Edit .env, set MONGO_URI and JWT_SECRET
npm install
npm run dev
```

### 2. Frontend
```bash
cd frontend
npm install
# Create .env file with VITE_API_URL, for example:
# VITE_API_URL=http://localhost:4000
echo "VITE_API_URL=http://localhost:4000" > .env
npm run dev
```

## Deployment
- Backend on Render, Railway, or Fly.io
- Frontend on Vercel or Netlify
- Set CORS_ORIGIN to your deployed frontend URL

### Render (backend)
1. Create new Web Service from GitHub repo, root = `backend`
2. Environment:
   - `MONGO_URI` from MongoDB Atlas
   - `JWT_SECRET` long random string
   - `CORS_ORIGIN` comma separated, e.g. `https://your-frontend.vercel.app`
3. Build command: `npm install`
4. Start command: `npm start`

### Vercel (frontend)
1. New Project from GitHub, root = `frontend`
2. Add env `VITE_API_URL` pointing to your backend URL
3. Deploy

## Notes
- Default design is white with purple accents
- Recharts used for graphs
